# نفت پارس بات
WebView app for https://roghan1.parsoilco.ir/DirectSaleAppointment : watches the appointment list / Create page and sounds a loud alarm when capacity opens.
Build: Android Studio, or `gradle assembleDebug`.
