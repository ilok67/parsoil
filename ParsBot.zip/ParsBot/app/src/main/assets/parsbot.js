const N = window.PBNative;
const kv = {
    get(k, d) { try { const r = N && N.get(k); return r == null ? d : JSON.parse(r); } catch (_) { return d; } },
    set(k, v) { try { if (N) N.set(k, JSON.stringify(v)); } catch (_) {} }
};
const ss = {
    get(k, d) { try { const r = sessionStorage.getItem(k); return r == null ? d : JSON.parse(r); } catch (_) { return d; } },
    set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (_) {} }
};

const path = location.pathname.replace(/\/+$/, '').toLowerCase();
const isList = path === '/directsaleappointment';
const isCreate = path.indexOf('/directsaleappointment/create') === 0;

const faToEn = s => String(s || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const pad = n => String(n).padStart(2, '0');
const clock = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); };
const watching = () => ss.get('pb_watch', false) === true;

let timer = null;

function nextDelay() {
    const now = new Date();
    const sec = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
    const burst = sec >= 7 * 3600 + 59 * 60 + 30 && sec <= 8 * 3600 + 2 * 60;
    const base = burst ? 3 : Math.max(5, Number(kv.get('pb_interval', 10)) || 10);
    return Math.round(base * 1000 * (0.85 + Math.random() * 0.3));
}

function visible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
}

function checkList() {
    const cards = [...document.querySelectorAll('.pars-rec-card')];
    if (!cards.length) return { state: 'none', text: 'نوبت فعالی در فهرست نیست' };
    const changed = [];
    cards.forEach(card => {
        const badge = card.querySelector('.pars-rec-badge');
        const badgeText = badge ? badge.textContent.trim() : '';
        const full = (badge && badge.classList.contains('closed')) || /تکمیل/.test(badgeText);
        if (!full) {
            const day = (card.querySelector('.pars-rec-day') || {}).textContent || '';
            const date = (card.querySelector('.pars-rec-date') || {}).textContent || '';
            changed.push((day + ' ' + date).trim() + (badgeText ? ' (' + badgeText + ')' : ''));
        }
    });
    if (changed.length) return { state: 'open', text: 'تغییر وضعیت: ' + changed.join('، ') };
    return { state: 'full', text: 'ظرفیت همه‌ی روزها تکمیل است' };
}

function checkCreate() {
    return new Promise(resolve => {
        const started = Date.now();
        (function poll() {
            const text = document.body ? document.body.innerText : '';
            if (/تکمیل\s*شده/.test(text)) return resolve({ state: 'full', text: 'ظرفیت تکمیل است' });
            const fields = [...document.querySelectorAll('input, select, textarea')].filter(el =>
                !el.closest('#pb-panel') && !/^(hidden|submit|button|checkbox|radio)$/i.test(el.type || '') && visible(el));
            if (fields.length) return resolve({ state: 'open', text: 'فرم نوبت باز شد', fields });
            if (Date.now() - started > 5000) return resolve({ state: 'unknown', text: 'وضعیت نامشخص (نه پیام ظرفیت، نه فرم)' });
            setTimeout(poll, 250);
        })();
    });
}

function setValue(el, value) {
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
}

function labelOf(el) {
    let t = [el.name, el.id, el.placeholder, el.getAttribute('aria-label')].join(' ');
    if (el.id) { const l = document.querySelector('label[for="' + el.id + '"]'); if (l) t += ' ' + l.textContent; }
    const wrap = el.closest('.form-group, .mb-3, .col, div'); if (wrap) { const l = wrap.querySelector('label'); if (l) t += ' ' + l.textContent; }
    return t;
}

function autofill(fields) {
    const nid = faToEn(kv.get('pb_nid', ''));
    const mobile = faToEn(kv.get('pb_mobile', ''));
    const done = [];
    fields.forEach(el => {
        if (el.value || el.tagName === 'SELECT') return;
        const t = labelOf(el);
        if (nid && /کد\s*ملی|national|codemeli|nid/i.test(t)) { setValue(el, nid); done.push('کد ملی'); }
        else if (mobile && /موبایل|همراه|تلفن|mobile|cell|phone/i.test(t)) { setValue(el, mobile); done.push('موبایل'); }
    });
    return done;
}

function found(res) {
    ss.set('pb_watch', false);
    clearTimeout(timer);
    let extra = '';
    if (res.fields) { const d = autofill(res.fields); if (d.length) extra = ' • پر شد: ' + d.join('، '); }
    setStatus('🚨 ' + res.text + extra, 'alert');
    render();
    try { if (N) N.alarm(); } catch (_) {}
}

async function cycle() {
    if (!watching()) return;
    const res = isList ? checkList() : isCreate ? await checkCreate() : { state: 'idle', text: 'در این صفحه پایش نمی‌شود' };
    const n = ss.get('pb_checks', 0) + 1;
    ss.set('pb_checks', n);
    if (res.state === 'open') return found(res);
    const delay = nextDelay();
    setStatus('بررسی #' + n + ' • ' + clock() + ' • ' + res.text + ' • بعدی ' + Math.round(delay / 1000) + 'ث');
    timer = setTimeout(() => location.reload(), delay);
}

let statusEl, toggleEl, settingsEl;
function setStatus(t, mode) {
    if (!statusEl) return;
    statusEl.textContent = t;
    statusEl.style.color = mode === 'alert' ? '#fde047' : '#e6fbff';
}
function render() {
    if (!toggleEl) return;
    toggleEl.textContent = watching() ? '■ توقف' : '▶ شروع پایش';
    toggleEl.style.background = watching() ? '#b91c1c' : '#0891b2';
}

function buildPanel() {
    if (document.getElementById('pb-panel')) return;
    const css = 'font:14px/1.6 Tahoma,sans-serif;direction:rtl;color:#e6fbff;box-sizing:border-box;';
    const panel = document.createElement('div');
    panel.id = 'pb-panel';
    panel.style.cssText = css + 'position:fixed;left:50%;bottom:10px;transform:translateX(-50%);width:min(94vw,400px);' +
        'background:rgba(11,27,43,.97);border:1px solid #22d3ee;border-radius:14px;padding:10px;z-index:2147483647;' +
        'box-shadow:0 6px 24px rgba(6,182,212,.35);';
    const btn = (txt, bg) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = txt;
        b.style.cssText = css + 'border:0;border-radius:10px;padding:8px 12px;background:' + bg + ';color:#fff;font-weight:bold;'; return b; };
    const input = (ph, key, mode) => { const i = document.createElement('input'); i.placeholder = ph; i.inputMode = mode;
        i.value = kv.get(key, ''); i.style.cssText = css + 'width:100%;margin-top:6px;padding:8px;border-radius:8px;border:1px solid #1f6a8a;background:#0e2236;color:#e6fbff;';
        i.addEventListener('input', () => kv.set(key, i.value.trim())); return i; };

    statusEl = document.createElement('div');
    statusEl.textContent = isList ? 'آماده: فهرست نوبت‌ها را پایش می‌کنم' : isCreate ? 'آماده: صفحه‌ی ثبت نوبت را پایش می‌کنم' : 'این صفحه پایش نمی‌شود';
    statusEl.style.cssText = css + 'font-size:13px;margin-bottom:8px;word-break:break-word;';

    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:8px;';
    toggleEl = btn('', '#0891b2'); toggleEl.style.flex = '1';
    const gear = btn('⚙', '#12304a');
    const copy = btn('📋', '#12304a');
    copy.title = 'کپی HTML صفحه';
    row.append(toggleEl, copy, gear);

    settingsEl = document.createElement('div');
    settingsEl.style.display = 'none';
    const every = input('فاصله‌ی بررسی (ثانیه، حداقل ۵)', 'pb_interval', 'numeric');
    settingsEl.append(input('کد ملی', 'pb_nid', 'numeric'), input('شماره موبایل', 'pb_mobile', 'tel'), every);
    const hint = document.createElement('div');
    hint.textContent = 'نزدیک ساعت ۸:۰۰ فاصله خودکار ۳ ثانیه می‌شود. فرم به‌صورت خودکار ارسال نمی‌شود.';
    hint.style.cssText = css + 'font-size:11px;color:#7fa6bd;margin-top:6px;';
    settingsEl.append(hint);

    toggleEl.addEventListener('click', () => {
        if (watching()) { ss.set('pb_watch', false); clearTimeout(timer); setStatus('پایش متوقف شد'); render(); }
        else { ss.set('pb_watch', true); ss.set('pb_checks', 0); render(); setStatus('شروع شد...'); cycle(); }
    });
    gear.addEventListener('click', () => { settingsEl.style.display = settingsEl.style.display === 'none' ? 'block' : 'none'; });
    copy.addEventListener('click', () => { try { if (N) N.copy(document.documentElement.outerHTML); } catch (_) {} });

    panel.append(statusEl, row, settingsEl);
    document.body.appendChild(panel);
    render();
}

function boot() {
    buildPanel();
    if (watching()) { setStatus('ادامه‌ی پایش...'); cycle(); }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
