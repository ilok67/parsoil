const N = window.PBNative;
const kv = {
    get(k, d) { try { const r = N && N.get(k); return r == null ? d : JSON.parse(r); } catch (_) { return d; } },
    set(k, v) { try { if (N) N.set(k, JSON.stringify(v)); } catch (_) {} }
};
const ss = {
    get(k, d) { try { const r = sessionStorage.getItem(k); return r == null ? d : JSON.parse(r); } catch (_) { return d; } },
    set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (_) {} }
};

const path = location.pathname.replace(/\/+$/, '').toLowerCase();
const isList = path === '/directsaleappointment';
const isCreate = path.indexOf('/directsaleappointment/create') === 0;

const faToEn = s => String(s == null ? '' : s).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const pad = n => String(n).padStart(2, '0');
const clock = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const normCode = v => faToEn(v).replace(/\D/g, '');
const UI_CSS = 'font:14px/1.6 Tahoma,sans-serif;direction:rtl;color:#e6fbff;box-sizing:border-box;';

const DEF = {
    nid: '', mobile: '', fname: '', lname: '', birth: '', gender: '1', vin: '', carModel: '', km: '', carType: '',
    plIr: '', pl3: '', plLetter: '', pl2: '', products: {}, interval: 10, autosubmit: true
};
const cfg = () => Object.assign({}, DEF, kv.get('pb_cfg', {}));
const saveCfg = patch => kv.set('pb_cfg', Object.assign(cfg(), patch));

const PRODUCTS = [
    ['9217383600', 'پایا SL10W40 پلاس - ۴ لیتری', 1], ['9217403630', 'پایا پریمیوم 20W50 - ۴ لیتری', 1],
    ['9207383700', 'فلومکس SL10W40 - ۵ لیتری', 1], ['9217383700', 'پایا SL10W40 پلاس - ۵ لیتری', 1],
    ['9207903750', 'سوپرپیشرو SM 10W40 - ۵ لیتری', 1], ['9207903650', 'سوپرپیشرو SM 10W40 - ۴ لیتری', 1],
    ['9521003500', 'ضدیخ سهند - ۱ کیلویی', 4], ['9406051510', 'شاسی کلسیم +3 - تیوپی', 4],
    ['9413051510', 'گریس ماهان 3 - تیوپی', 4], ['9311033560', 'فلومکس موتوربایک SN 10W50', 4],
    ['9311033580', 'فلومکس موتوربایک SL 10W40', 4]
];
const CAR_TYPES = ['سایر', 'پژو پارس', 'سمند', 'پژو 405', 'پژو 206', 'پژو 207', 'کوییک', 'پیکان', 'دنا', 'شاهین', 'تارا', 'رانا',
    'دنا پلاس', 'وانت', 'اطلس', 'نیسان', 'تیبا', 'ال نود', 'مگان', 'ساینا', 'پژو رو آ', 'پژو آردی', 'پراید', 'ریو', 'جک'];
const LETTERS = ['الف', 'ب', 'ت', 'ج', 'چ-ژ', 'د', 'س', 'ص', 'ط', 'ع', 'ق', 'گ', 'ل', 'م', 'ن', 'و', 'هـ', 'ی', 'D', 'S'];

const FULL_RE = /ظرفیت\s*نوبت\s*برای\s*تاریخ\s*مراجعه[^<]{0,80}تکمیل\s*شده/;
const NOTSTARTED_RE = /نوبت.?دهی\s*هنوز\s*آغاز\s*نشده/;

const watching = () => ss.get('pb_watch', false) === true;
let timer = null;
let busyStreak = 0;

function inBurst() {
    const n = new Date();
    const s = n.getHours() * 3600 + n.getMinutes() * 60 + n.getSeconds();
    return s >= 7 * 3600 + 59 * 60 && s <= 8 * 3600 + 15 * 60;
}

function nextDelay(busy) {
    const interval = Math.max(5, Number(cfg().interval) || 10);
    let base = inBurst() ? 2.5 : interval;
    if (busy) base = Math.max(base, inBurst() ? 3.5 : 8) * Math.min(2, 1 + busyStreak * 0.1);
    return Math.round(base * 1000 * (0.7 + Math.random() * 0.6));
}

function evalCards(cards) {
    if (!cards.length) return { state: 'wait', text: 'نوبت فعالی در فهرست نیست' };
    const open = cards.filter(c => c.querySelector('.pars-rec-badge.open'));
    if (open.length) {
        const c = open[0];
        const day = ((c.querySelector('.pars-rec-day') || {}).textContent || '').trim();
        const date = ((c.querySelector('.pars-rec-date') || {}).textContent || '').trim();
        return { state: 'open', text: 'در حال نوبت‌دهی: ' + day + ' ' + date, href: c.getAttribute('href') };
    }
    const soon = cards.filter(c => c.querySelector('.pars-rec-badge.soon')).length;
    return { state: 'wait', text: soon ? soon + ' روز «به‌زودی» شروع می‌شود' : 'ظرفیت همه‌ی روزها تکمیل است' };
}

function classifyCreate(text) {
    if (/id=["']attForm["']/.test(text)) return { state: 'open', text: 'فرم نوبت باز شد' };
    if (NOTSTARTED_RE.test(text)) return { state: 'wait', text: 'نوبت‌دهی هنوز شروع نشده' };
    if (FULL_RE.test(text)) return { state: 'wait', text: 'ظرفیت تکمیل است' };
    return { state: 'wait', text: 'وضعیت نامشخص' };
}

async function fetchPage(url) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 15000);
    try {
        const r = await fetch(url, { credentials: 'include', cache: 'no-store', signal: ctl.signal });
        if (r.status >= 500 || r.status === 429 || r.status === 408) return { busy: true, text: 'سرور شلوغ است (HTTP ' + r.status + ')' };
        if (!r.ok) return { fatal: true, text: 'پاسخ سرور: HTTP ' + r.status };
        return { html: await r.text() };
    } catch (_) {
        return { busy: true, text: 'اتصال برقرار نشد' };
    } finally { clearTimeout(t); }
}

function report(res, busy) {
    const n = ss.get('pb_checks', 0) + 1;
    ss.set('pb_checks', n);
    const delay = nextDelay(busy);
    setStatus('بررسی #' + n + ' • ' + clock() + ' • ' + res.text + ' • بعدی ' + (delay / 1000).toFixed(1) + 'ث');
    timer = setTimeout(loop, delay);
}

async function loop() {
    if (!watching()) return;
    const r = await fetchPage(location.href);
    if (!watching()) return;
    if (r.busy) { busyStreak++; return report(r, true); }
    busyStreak = 0;
    if (r.fatal) return report(r, false);
    const res = isList
        ? evalCards([...new DOMParser().parseFromString(r.html, 'text/html').querySelectorAll('.pars-rec-card')])
        : classifyCreate(r.html);
    if (res.state === 'open') return openFound(res);
    report(res, false);
}

async function openFound(res) {
    clearTimeout(timer);
    setStatus('🚨 ' + res.text + ' — در حال باز کردن فرم...', 'alert');
    try { if (N) N.alarm(); } catch (_) {}
    const target = isList ? new URL(res.href, location.href).href : location.href;
    for (let i = 0; i < 80 && watching(); i++) {
        const r = await fetchPage(target);
        if (r.html) {
            const c = classifyCreate(r.html);
            if (c.state === 'open') {
                ss.set('pb_watch', false);
                if (isCreate) location.reload(); else location.href = target;
                return;
            }
            if (c.state === 'wait' && i > 0) break;
        }
        setStatus('🚨 ' + res.text + ' — سرور شلوغ است، دوباره تلاش می‌کنم (' + (i + 1) + ')', 'alert');
        await sleep(1200 + Math.random() * 1800);
    }
    if (watching()) report({ text: 'فرصت از دست رفت؛ ادامه‌ی پایش' }, false);
}

function checkCreateDom() {
    return new Promise(resolve => {
        const t0 = Date.now();
        (function poll() {
            if (document.getElementById('attForm')) return resolve({ state: 'open', text: 'فرم نوبت باز شد' });
            const text = document.body ? document.body.innerText : '';
            if (NOTSTARTED_RE.test(text)) return resolve({ state: 'wait', text: 'نوبت‌دهی هنوز شروع نشده' });
            if (FULL_RE.test(text)) return resolve({ state: 'wait', text: 'ظرفیت تکمیل است' });
            if (Date.now() - t0 > 4000) return resolve({ state: 'wait', text: 'وضعیت نامشخص' });
            setTimeout(poll, 250);
        })();
    });
}

async function cycle() {
    if (!watching()) return;
    const res = isList
        ? evalCards([...document.querySelectorAll('.pars-rec-card')])
        : isCreate ? await checkCreateDom() : { state: 'wait', text: 'در این صفحه پایش نمی‌شود' };
    if (res.state === 'open') return isCreate ? onForm() : openFound(res);
    report(res, false);
}

function setVal(id, v) {
    const el = document.getElementById(id);
    if (!el || v === '' || v == null) return false;
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, String(v));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    if (window.jQuery) { try { window.jQuery(el).trigger('change'); } catch (_) {} }
    return true;
}

function b64ToFile(b64, name) {
    const bin = atob(b64);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return new File([u], name, { type: 'image/jpeg', lastModified: Date.now() });
}

function fillForm() {
    const c = cfg();
    const done = [];
    const put = (id, v, label) => { if (setVal(id, v)) done.push(label); };
    put('NationalId', faToEn(c.nid), 'کد ملی');
    put('Mobile', faToEn(c.mobile), 'موبایل');
    put('F_Name', c.fname, 'نام');
    put('L_Name', c.lname, 'نام خانوادگی');
    put('BirthDateString', faToEn(c.birth), 'تاریخ تولد');
    const g = document.getElementById(c.gender === '2' ? 'Gender_1' : 'Gender_0');
    if (g) { g.click(); done.push('جنسیت'); }
    put('VIN', c.vin.toUpperCase(), 'VIN');
    put('CarModel', faToEn(c.carModel), 'مدل');
    put('Kilometer', faToEn(c.km), 'کیلومتر');
    put('Type_Car', c.carType, 'نوع خودرو');
    put('irDigit', faToEn(c.plIr), 'پلاک');
    put('threeDigit', faToEn(c.pl3), '');
    put('letter', c.plLetter, '');
    put('twoDigit', faToEn(c.pl2), '');

    const want = c.products || {};
    const wantedCodes = Object.keys(want).map(normCode);
    let matched = 0;
    const seen = [];
    document.querySelectorAll('#tblProducts tbody tr').forEach(row => {
        const code = normCode(row.children[2] ? row.children[2].textContent : '');
        seen.push(code);
        const key = Object.keys(want).find(k => normCode(k) === code);
        const cb = row.querySelector('.product-check');
        if (!key || !cb) return;
        if (!cb.checked) cb.click();
        if (!cb.checked) { cb.checked = true; cb.dispatchEvent(new Event('change', { bubbles: true })); }
        const q = row.querySelector('.product-qty');
        if (q) {
            q.disabled = false;
            q.value = String(want[key]);
            q.dispatchEvent(new Event('input', { bubbles: true }));
            q.dispatchEvent(new Event('change', { bubbles: true }));
        }
        matched++;
    });
    if (!wantedCodes.length) done.push('⚠️ محصولی در تنظیمات انتخاب نشده');
    else if (matched) done.push('محصول');
    else done.push('⚠️ محصول انتخابی در فرم نبود (کدهای فرم: ' + seen.slice(0, 3).join('،') + '...)');

    ['carCardFront', 'carCardBack'].forEach(slot => {
        const input = document.getElementById(slot);
        const b64 = N && N.getImage ? N.getImage(slot) : '';
        if (!input || !b64) return;
        try {
            const dt = new DataTransfer();
            dt.items.add(b64ToFile(b64, slot + '.jpg'));
            input.files = dt.files;
            input.dispatchEvent(new Event('change', { bubbles: true }));
            done.push('عکس');
        } catch (_) {}
    });
    return [...new Set(done.filter(Boolean))];
}

function onForm() {
    const was = watching();
    ss.set('pb_watch', false);
    clearTimeout(timer);
    render();
    if (was) { try { if (N) N.alarm(); } catch (_) {} }
    setTimeout(() => {
        const done = fillForm();
        liveProducts();
        setStatus('✅ فرم باز است • پر شد: ' + (done.join('، ') || 'چیزی ذخیره نشده') + ' • کد امنیتی را وارد کن', 'alert');
        const cap = document.getElementById('Captcha');
        if (cap && !cap.dataset.pbBound) {
            cap.dataset.pbBound = '1';
            try { cap.scrollIntoView({ block: 'center' }); cap.focus(); } catch (_) {}
            cap.addEventListener('input', () => {
                if (!cfg().autosubmit || cap.value.trim().length < 6) return;
                setTimeout(() => {
                    const b = document.getElementById('btn-register1');
                    if (b && !b.disabled && b.offsetParent) b.click();
                }, 200);
            });
        }
        const out = document.getElementById('modal-result');
        if (out && window.MutationObserver) {
            new MutationObserver(() => {
                const msg = out.textContent.trim();
                if (msg) setStatus((out.querySelector('.alert-success') ? '✅ ' : '⚠️ ') + msg, out.querySelector('.alert-success') ? 'alert' : '');
            }).observe(out, { childList: true, subtree: true, characterData: true });
        }
    }, 400);
}

let statusEl, toggleEl, settingsEl, bodyEl;

function liveProducts() {
    const rows = [...document.querySelectorAll('#tblProducts tbody tr')];
    if (!rows.length || !bodyEl || document.getElementById('pb-live')) return;
    const list = rows.map(r => {
        const qty = r.querySelector('.product-qty');
        return {
            row: r,
            code: normCode(r.children[2] ? r.children[2].textContent : ''),
            name: (r.children[3] ? r.children[3].textContent : '').replace(/[\u200f\s]+/g, ' ').trim(),
            max: Number(qty ? qty.getAttribute('data-max') : 1) || 1
        };
    });
    kv.set('pb_rows', list.map(x => [x.code, x.name, x.max]));
    const box = document.createElement('div');
    box.id = 'pb-live';
    box.style.cssText = UI_CSS + 'margin-top:8px;max-height:30vh;overflow:auto;border-top:1px solid #1f6a8a;padding-top:6px;';
    const title = document.createElement('div');
    title.style.cssText = UI_CSS + 'font-size:12px;color:#7fa6bd;';
    title.textContent = '🛒 محصولات این فرم — برای انتخاب لمس کن';
    box.append(title);
    const buttons = list.map(x => {
        const b = document.createElement('button');
        b.type = 'button';
        b.style.cssText = UI_CSS + 'display:block;width:100%;text-align:right;margin-top:4px;padding:6px 8px;border:1px solid #1f6a8a;border-radius:8px;background:#0e2236;font-size:12px;';
        return { x, b };
    });
    const refresh = () => buttons.forEach(({ x, b }) => {
        const cb = x.row.querySelector('.product-check');
        const on = !!(cb && cb.checked);
        b.textContent = (on ? '☑ ' : '☐ ') + x.name + (x.max > 1 ? ' (حداکثر ' + x.max + ')' : '');
        b.style.borderColor = on ? '#22d3ee' : '#1f6a8a';
    });
    buttons.forEach(({ x, b }) => {
        b.addEventListener('click', () => {
            const cb = x.row.querySelector('.product-check');
            if (!cb) return;
            cb.click();
            const p = Object.assign({}, cfg().products);
            const drop = code => Object.keys(p).forEach(k => { if (normCode(k) === code) delete p[k]; });
            drop(x.code);
            if (cb.checked) {
                if (x.max === 1) list.forEach(y => { if (y.max === 1) drop(y.code); });
                p[x.code] = 1;
            }
            saveCfg({ products: p });
            refresh();
        });
        box.append(b);
    });
    refresh();
    bodyEl.append(box);
}
function setStatus(t, mode) {
    if (!statusEl) return;
    statusEl.textContent = t;
    statusEl.style.color = mode === 'alert' ? '#fde047' : '#e6fbff';
}
function render() {
    if (!toggleEl) return;
    toggleEl.textContent = watching() ? '■ توقف' : '▶ شروع پایش';
    toggleEl.style.background = watching() ? '#b91c1c' : '#0891b2';
}

function buildPanel() {
    if (document.getElementById('pb-panel')) return;
    const css = UI_CSS;
    const mk = (tag, style, props) => Object.assign(document.createElement(tag), props || {}, { }), 
        sty = (el, s) => { el.style.cssText = css + s; return el; };
    const btn = (txt, bg, extra) => { const b = mk('button'); b.type = 'button'; b.textContent = txt;
        return sty(b, 'border:0;border-radius:10px;padding:8px 12px;color:#fff;font-weight:bold;background:' + bg + ';' + (extra || '')); };
    const inputCss = 'width:100%;padding:7px;border-radius:8px;border:1px solid #1f6a8a;background:#0e2236;color:#e6fbff;';
    const label = txt => sty(mk('div', '', { textContent: txt }), 'font-size:12px;color:#7fa6bd;margin-top:8px;');

    const panel = sty(mk('div'), 'position:fixed;left:50%;bottom:10px;transform:translateX(-50%);width:min(94vw,420px);' +
        'background:rgba(11,27,43,.97);border:1px solid #22d3ee;border-radius:14px;padding:10px;z-index:2147483647;' +
        'box-shadow:0 6px 24px rgba(6,182,212,.35);');
    panel.id = 'pb-panel';

    const head = sty(mk('div'), 'display:flex;gap:8px;align-items:flex-start;');
    statusEl = sty(mk('div'), 'flex:1;font-size:13px;word-break:break-word;');
    const m = location.hostname.match(/^roghan(\d+)\./i);
    statusEl.textContent = 'سرور ' + (m ? m[1] : '؟') + ' • ' + (isList ? 'آماده: فهرست نوبت‌ها' : isCreate ? 'آماده: صفحه‌ی ثبت نوبت' : 'این صفحه پایش نمی‌شود');
    const fold = btn('▾', '#12304a', 'padding:2px 10px;');
    head.append(statusEl, fold);

    bodyEl = mk('div');
    const row = sty(mk('div'), 'display:flex;gap:8px;margin-top:8px;');
    toggleEl = btn('', '#0891b2', 'flex:1;');
    const sw = btn('🔁', '#12304a'); sw.title = 'تعویض سرور (roghan1 / roghan2)';
    const copy = btn('📋', '#12304a'); copy.title = 'کپی HTML صفحه';
    const gear = btn('⚙', '#12304a');
    row.append(toggleEl, sw, copy, gear);

    settingsEl = sty(mk('div'), 'display:none;max-height:48vh;overflow:auto;margin-top:8px;padding-top:2px;border-top:1px solid #1f6a8a;');
    const c0 = cfg();
    const textField = (title, key, mode, max) => {
        const i = sty(mk('input'), inputCss); i.inputMode = mode; if (max) i.maxLength = max; i.value = c0[key] == null ? '' : c0[key];
        i.addEventListener('input', () => saveCfg({ [key]: i.value.trim() }));
        settingsEl.append(label(title), i); return i;
    };
    const selectField = (title, key, opts) => {
        const s = sty(mk('select'), inputCss);
        s.append(Object.assign(mk('option'), { value: '', textContent: '— انتخاب —' }));
        opts.forEach(([v, t]) => s.append(Object.assign(mk('option'), { value: v, textContent: t })));
        s.value = c0[key] || '';
        s.addEventListener('change', () => saveCfg({ [key]: s.value }));
        settingsEl.append(label(title), s); return s;
    };
    textField('کد ملی', 'nid', 'numeric', 10);
    textField('موبایل (09...)', 'mobile', 'tel', 11);
    textField('نام', 'fname', 'text');
    textField('نام خانوادگی', 'lname', 'text');
    textField('تاریخ تولد (مثال 1370/05/20)', 'birth', 'text', 10);
    selectField('جنسیت', 'gender', [['1', 'مرد'], ['2', 'زن']]);
    textField('VIN (۱۷ حرف)', 'vin', 'text', 17);
    const years = []; for (let y = 1405; y >= 1350; y--) years.push([String(y), y + ' - ' + (y + 621)]);
    selectField('مدل خودرو (سال)', 'carModel', years);
    textField('کیلومتر فعلی (اختیاری)', 'km', 'numeric', 7);
    selectField('نوع خودرو', 'carType', CAR_TYPES.map((t, i) => [String(i + 1), t]));
    settingsEl.append(label('پلاک: دو رقم | حرف | سه رقم | ایران'));
    const plRow = sty(mk('div'), 'display:flex;gap:6px;');
    const plBox = (key, ph, max) => { const i = sty(mk('input'), inputCss + 'text-align:center;'); i.placeholder = ph; i.inputMode = 'numeric'; i.maxLength = max;
        i.value = c0[key] || ''; i.addEventListener('input', () => saveCfg({ [key]: i.value.trim() })); return i; };
    const pl2 = plBox('pl2', '33', 2);
    const letter = sty(mk('select'), inputCss);
    letter.append(Object.assign(mk('option'), { value: '', textContent: 'حرف' }));
    LETTERS.forEach(l => letter.append(Object.assign(mk('option'), { value: l, textContent: l })));
    letter.value = c0.plLetter || ''; letter.addEventListener('change', () => saveCfg({ plLetter: letter.value }));
    plRow.append(pl2, letter, plBox('pl3', '333', 3), plBox('plIr', '33', 2));
    settingsEl.append(plRow);

    settingsEl.append(label('محصولات (از روغن‌های ۴/۵ لیتری فقط یکی)'));
    const seenRows = kv.get('pb_rows', null);
    const plist = Array.isArray(seenRows) && seenRows.length ? seenRows : PRODUCTS;
    plist.forEach(([code, name, max]) => {
        const r = sty(mk('div'), 'display:flex;align-items:center;gap:6px;margin-top:4px;font-size:12px;');
        const cb = mk('input', '', { type: 'checkbox' }); cb.checked = !!(c0.products || {})[code];
        const nm = sty(mk('span', '', { textContent: name }), 'flex:1;font-size:12px;');
        const q = sty(mk('select'), inputCss + 'width:60px;');
        for (let k = 1; k <= max; k++) q.append(Object.assign(mk('option'), { value: String(k), textContent: String(k) }));
        q.value = String((c0.products || {})[code] || 1); q.style.display = max > 1 ? '' : 'none';
        const sync = () => {
            const p = Object.assign({}, cfg().products);
            if (cb.checked) {
                if (max === 1) plist.forEach(([c2, , m2]) => { if (m2 === 1) delete p[c2]; });
                p[code] = Number(q.value);
            } else delete p[code];
            saveCfg({ products: p });
            settingsEl.querySelectorAll('input[data-single]').forEach(x => { x.checked = !!p[x.dataset.single]; });
        };
        if (max === 1) cb.dataset.single = code;
        cb.addEventListener('change', sync); q.addEventListener('change', sync);
        r.append(cb, nm, q); settingsEl.append(r);
    });

    settingsEl.append(label('عکس کارت خودرو (یک بار انتخاب کن؛ خودکار در فرم گذاشته می‌شود)'));
    [['carCardFront', 'روی کارت'], ['carCardBack', 'پشت کارت']].forEach(([slot, title]) => {
        const b = btn('', '#12304a', 'width:100%;margin-top:4px;font-weight:normal;font-size:13px;');
        const upd = () => { let kb = '0'; try { kb = N && N.imageInfo ? N.imageInfo(slot) : '0'; } catch (_) {}
            b.textContent = (kb !== '0' ? '✔ ' : '📷 ') + title + (kb !== '0' ? ' (' + kb + ' کیلوبایت)' : ' — انتخاب عکس'); };
        upd();
        b.addEventListener('click', () => { try { if (N) N.pickImage(slot); } catch (_) {} });
        (window.__pbPhotoCbs = window.__pbPhotoCbs || {})[slot] = upd;
        settingsEl.append(b);
    });
    window.__pbPhoto = slot => { const f = (window.__pbPhotoCbs || {})[slot]; if (f) f(); };

    textField('فاصله‌ی بررسی (ثانیه، حداقل ۵)', 'interval', 'numeric', 3);
    const asRow = sty(mk('label'), 'display:flex;gap:8px;align-items:center;margin-top:10px;font-size:13px;');
    const as = mk('input', '', { type: 'checkbox' }); as.checked = c0.autosubmit !== false;
    as.addEventListener('change', () => saveCfg({ autosubmit: as.checked }));
    asRow.append(as, document.createTextNode('ثبت خودکار بعد از وارد کردن ۶ حرف کد امنیتی'));
    const hint = sty(mk('div', '', { textContent: 'از ۷:۵۹ تا ۸:۱۵ فاصله‌ی بررسی خودکار حدود ۲.۵ ثانیه می‌شود و با خطای ۵۰۳ هم پایش ادامه می‌یابد. کد امنیتی را خودت وارد کن.' }),
        'font-size:11px;color:#7fa6bd;margin-top:8px;');
    settingsEl.append(asRow, hint);

    toggleEl.addEventListener('click', () => {
        if (watching()) { ss.set('pb_watch', false); clearTimeout(timer); setStatus('پایش متوقف شد'); render(); }
        else { ss.set('pb_watch', true); ss.set('pb_checks', 0); busyStreak = 0; render(); setStatus('شروع شد...'); cycle(); }
    });
    gear.addEventListener('click', () => { settingsEl.style.display = settingsEl.style.display === 'none' ? 'block' : 'none'; });
    copy.addEventListener('click', () => { try { if (N) N.copy(document.documentElement.outerHTML); } catch (_) {} });
    sw.addEventListener('click', () => {
        const mm = location.hostname.match(/^roghan(\d+)\./i);
        const next = 'roghan' + ((mm ? mm[1] : '1') === '1' ? '2' : '1') + '.parsoilco.ir';
        try { if (N && N.setHost) N.setHost(next); } catch (_) {}
        location.href = 'https://' + next + '/DirectSaleAppointment';
    });
    fold.addEventListener('click', () => {
        const hidden = bodyEl.style.display === 'none';
        bodyEl.style.display = hidden ? 'block' : 'none';
        fold.textContent = hidden ? '▾' : '▴';
    });

    bodyEl.append(row, settingsEl);
    panel.append(head, bodyEl);
    document.body.appendChild(panel);
    render();
}

function boot() {
    buildPanel();
    if (document.getElementById('attForm')) return onForm();
    if (watching()) { setStatus('ادامه‌ی پایش...'); cycle(); }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
