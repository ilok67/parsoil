package ir.parsbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max

/** Keeps the two car-card photos (JPEG, under 450 KB) in the app's private storage. */
class ImageStore(private val ctx: Context) {
    private fun file(slot: String) = File(ctx.filesDir, "img_" + slot.filter { it.isLetterOrDigit() } + ".jpg")

    fun info(slot: String): String =
        file(slot).takeIf { it.exists() }?.let { ((it.length() + 1023) / 1024).toString() } ?: "0"

    fun base64(slot: String): String =
        file(slot).takeIf { it.exists() }?.let { Base64.encodeToString(it.readBytes(), Base64.NO_WRAP) } ?: ""

    fun saveFrom(slot: String, uri: Uri): Boolean = runCatching {
        val resolver = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 3200) sample *= 2
        var bmp = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalStateException("decode failed")

        val orientation = resolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
        }

        var w = bmp.width
        var h = bmp.height
        val limit = 1600f / max(w, h).coerceAtLeast(1)
        if (limit < 1f) { w = (w * limit).toInt(); h = (h * limit).toInt() }
        var quality = 85
        var out = ByteArray(0)
        while (true) {
            val scaled = if (w != bmp.width) Bitmap.createScaledBitmap(bmp, w, h, true) else bmp
            val bos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, bos)
            out = bos.toByteArray()
            if (out.size <= 440 * 1024) break
            if (quality > 55) quality -= 10 else { w = (w * 0.85).toInt(); h = (h * 0.85).toInt() }
            if (max(w, h) < 500) break
        }
        file(slot).writeBytes(out)
        out.size <= 500 * 1024
    }.getOrDefault(false)
}
