package ir.parsbot

import android.webkit.JavascriptInterface

/** Exposed to page JS as `PBNative`. Values are JSON strings. */
class GmBridge(
    private val store: SecureStore,
    private val onAlarm: () -> Unit,
    private val onCopy: (String) -> Unit
) {
    @JavascriptInterface fun get(key: String?): String? = key?.takeIf { it.length in 1..200 }?.let(store::get)
    @JavascriptInterface fun set(key: String?, json: String?) {
        if (key == null || json == null || key.length !in 1..200 || json.length > 100_000) return
        store.set(key, json)
    }
    @JavascriptInterface fun alarm() = onAlarm()
    @JavascriptInterface fun copy(text: String?) { if (text != null && text.length < 900_000) onCopy(text) }
}
