package ir.parsbot

import android.webkit.JavascriptInterface

/** Exposed to page JS as `PBNative`. Values are JSON strings. */
class GmBridge(
    private val store: SecureStore,
    private val images: ImageStore,
    private val onAlarm: () -> Unit,
    private val onCopy: (String) -> Unit,
    private val onPick: (String) -> Unit,
    private val onHost: (String) -> Unit
) {
    private val slots = setOf("carCardFront", "carCardBack")

    @JavascriptInterface fun get(key: String?): String? = key?.takeIf { it.length in 1..200 }?.let(store::get)
    @JavascriptInterface fun set(key: String?, json: String?) {
        if (key == null || json == null || key.length !in 1..200 || json.length > 100_000) return
        store.set(key, json)
    }
    @JavascriptInterface fun alarm() = onAlarm()
    @JavascriptInterface fun copy(text: String?) { if (text != null && text.length < 900_000) onCopy(text) }
    @JavascriptInterface fun imageInfo(slot: String?): String = if (slot in slots) images.info(slot!!) else "0"
    @JavascriptInterface fun getImage(slot: String?): String = if (slot in slots) images.base64(slot!!) else ""
    @JavascriptInterface fun pickImage(slot: String?) { if (slot in slots) onPick(slot!!) }
    @JavascriptInterface fun setHost(host: String?) {
        if (host != null && Regex("^roghan\\d*\\.parsoilco\\.ir$").matches(host)) onHost(host)
    }
}
